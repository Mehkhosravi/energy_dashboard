import {
  require_leaflet_src
} from "./chunk-DGCGC3HI.js";
import "./chunk-G3PMV62Z.js";
export default require_leaflet_src();
