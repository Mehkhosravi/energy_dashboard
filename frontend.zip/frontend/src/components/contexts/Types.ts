
export type Province = {
  DEN_UTS: string;
  COD_PROV: number;
  CONS_ANNO: number;
};