export default function AccountPanel() {
  return (
    <div className="charts">
      <h3>Account</h3>

      <div style={{ marginTop: 8, fontSize: 13 }}>
        <p><strong>Name:</strong> Admin User</p>
        <p><strong>Role:</strong> Administrator</p>
        <p><strong>Email:</strong> admin@example.com</p>
      </div>
    </div>
  );
}
